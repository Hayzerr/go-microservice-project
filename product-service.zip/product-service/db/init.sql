CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price NUMERIC(10,2) NOT NULL,
    type VARCHAR(32) NOT NULL,
    stock INT NOT NULL,
    festival_id UUID,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Добавим несколько базовых товаров
INSERT INTO products (name, description, price, type, stock, festival_id)
VALUES
  ('VIP Ticket', 'Access to VIP zone', 150.00, 'TICKET', 1, gen_random_uuid()),
  ('Festival T-Shirt', 'Official festival merchandise', 25.00, 'MERCHANDISE', 100, gen_random_uuid()),
  ('Standard Ticket', 'General admission', 50.00, 'TICKET', 500, gen_random_uuid());
